import React from 'react';

function Footer()
{
    return(
        <div id="footer" className="row footerbg" style={{width:"101%",height:"45px"}}>
           
                <div className="container col-sm-4"><p className="text-white text-center"> </p></div>
                <div className="container  col-sm-4"><p className="text-white text-center">copyrights @Group-3 Capgemini</p></div> 
                <div className="container  col-sm-4"><p className="text-white text-center"></p> </div> 
            
        </div>
    )
}

export default Footer;