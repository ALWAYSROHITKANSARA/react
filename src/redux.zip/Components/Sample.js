import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom"
import Header from './Header'

function Sample()
{
    return (
        
        <div className="btn btn-primary">
            <a href="/header">Navig</a>
        </div>
 
    )
}

export default Sample;